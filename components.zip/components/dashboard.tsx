"use client"

import { useState } from "react"
import { AppSidebar } from "@/components/app-sidebar"
import { SidebarInset } from "@/components/ui/sidebar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
// Make sure the import for DashboardHeader is correct
import { DashboardHeader } from "@/components/dashboard-header"
import OverviewSection from "@/components/sections/overview-section"
import ContentAnalysisSection from "@/components/sections/content-analysis-section"
import CommunitySection from "@/components/sections/community-section"
import StorySection from "@/components/sections/story-section"
import PythonSection from "@/components/sections/python-section"

export default function Dashboard() {
  const [activeTab, setActiveTab] = useState("overview")

  return (
    <div className="flex h-screen w-full">
      <AppSidebar />
      <SidebarInset className="flex flex-col">
        <DashboardHeader />
        <main className="flex-1 overflow-auto p-4 md:p-6">
          <Tabs defaultValue="overview" value={activeTab} onValueChange={setActiveTab} className="space-y-4">
            <TabsList className="grid w-full grid-cols-5 bg-background/30 backdrop-blur-md">
              <TabsTrigger value="overview" className="text-sm md:text-base transition-all duration-300">
                Overview
              </TabsTrigger>
              <TabsTrigger value="content" className="text-sm md:text-base transition-all duration-300">
                Content Analysis
              </TabsTrigger>
              <TabsTrigger value="community" className="text-sm md:text-base transition-all duration-300">
                Community Insights
              </TabsTrigger>
              <TabsTrigger value="story" className="text-sm md:text-base transition-all duration-300">
                Story
              </TabsTrigger>
              <TabsTrigger value="python" className="text-sm md:text-base transition-all duration-300">
                Python Scripts
              </TabsTrigger>
            </TabsList>
            <TabsContent value="overview" className="space-y-4 animate-fade-in">
              <OverviewSection />
            </TabsContent>
            <TabsContent value="content" className="space-y-4 animate-fade-in">
              <ContentAnalysisSection />
            </TabsContent>
            <TabsContent value="community" className="space-y-4 animate-fade-in">
              <CommunitySection />
            </TabsContent>
            <TabsContent value="story" className="space-y-4 animate-fade-in">
              <StorySection />
            </TabsContent>
            <TabsContent value="python" className="space-y-4 animate-fade-in">
              <PythonSection />
            </TabsContent>
          </Tabs>
        </main>
      </SidebarInset>
    </div>
  )
}
