import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { AiSummaryBox } from "@/components/ui/summary-box"
import Image from "next/image"

export default function CommunitySection() {
  return (
    <div className="space-y-6">
      <div className="grid gap-6 md:grid-cols-2 stagger-children">
        <Card className="gradient-card card-hover">
          <CardHeader>
            <CardTitle>Sentiment Distribution</CardTitle>
            <CardDescription>Distribution of sentiment scores across all posts</CardDescription>
          </CardHeader>
          <CardContent className="flex justify-center">
            <Image
              src="/sentiment-distribution.png"
              alt="Sentiment Distribution"
              width={500}
              height={300}
              className="rounded-md transition-all duration-300 hover:scale-[1.02]"
            />
          </CardContent>
        </Card>
        <Card className="gradient-card card-hover">
          <CardHeader>
            <CardTitle>Sentiment vs. Engagement</CardTitle>
            <CardDescription>Relationship between sentiment and post engagement</CardDescription>
          </CardHeader>
          <CardContent className="flex justify-center">
            <Image
              src="/sentiment-engagement.png"
              alt="Sentiment vs Engagement"
              width={500}
              height={300}
              className="rounded-md transition-all duration-300 hover:scale-[1.02]"
            />
          </CardContent>
        </Card>
      </div>

      <div className="light-section animate-fade-in">
        <AiSummaryBox
          title="Sentiment Analysis Insights"
          content="Posts have an overall positive tone with average sentiment score of 0.42. This indicates a generally constructive discourse across the analyzed subreddits. The positive sentiment appears to be driven by educational and informative content, while political discussions show more polarized sentiment scores. Science-related content consistently demonstrates the highest positive sentiment. Sentiment scores tend to peak on Fridays and Saturdays, suggesting a more positive community engagement during weekends."
          type="sentiment"
        />
      </div>

      <Card className="gradient-card card-hover animate-fade-in">
        <CardHeader>
          <CardTitle>Reddit Network Visualization</CardTitle>
          <CardDescription>Connections between subreddits based on crossposting</CardDescription>
        </CardHeader>
        <CardContent className="flex justify-center">
          <Image
            src="/subreddit-network.png"
            alt="Subreddit Network"
            width={800}
            height={400}
            className="rounded-md transition-all duration-300 hover:scale-[1.02]"
          />
        </CardContent>
      </Card>

      <div className="dark-section">
        <AiSummaryBox
          title="Network Analysis Insights"
          content="The network analysis reveals 5 distinct communities centered around political discourse, technology, science, general discussion, and educational content. These communities show significant cross-posting activity, suggesting information flows freely between topic areas. A small group of users (approximately 15) serve as bridges between different communities, posting across multiple subreddits. These users have disproportionate influence on information flow and typically generate content with higher engagement metrics."
          type="network"
        />
      </div>

      <div className="grid gap-6 md:grid-cols-2 stagger-children">
        <Card className="gradient-card card-hover">
          <CardHeader>
            <CardTitle>Top Subreddits</CardTitle>
            <CardDescription>Most active subreddits by post count</CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Subreddit</TableHead>
                  <TableHead>Posts</TableHead>
                  <TableHead>Avg. Score</TableHead>
                  <TableHead>Sentiment</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                <TableRow className="transition-colors hover:bg-primary/5">
                  <TableCell className="font-medium">Anarchism</TableCell>
                  <TableCell>245</TableCell>
                  <TableCell>48.2</TableCell>
                  <TableCell>0.28</TableCell>
                </TableRow>
                <TableRow className="transition-colors hover:bg-primary/5">
                  <TableCell className="font-medium">Politics</TableCell>
                  <TableCell>186</TableCell>
                  <TableCell>62.7</TableCell>
                  <TableCell>-0.15</TableCell>
                </TableRow>
                <TableRow className="transition-colors hover:bg-primary/5">
                  <TableCell className="font-medium">Technology</TableCell>
                  <TableCell>142</TableCell>
                  <TableCell>53.1</TableCell>
                  <TableCell>0.42</TableCell>
                </TableRow>
                <TableRow className="transition-colors hover:bg-primary/5">
                  <TableCell className="font-medium">Science</TableCell>
                  <TableCell>115</TableCell>
                  <TableCell>72.4</TableCell>
                  <TableCell>0.56</TableCell>
                </TableRow>
                <TableRow className="transition-colors hover:bg-primary/5">
                  <TableCell className="font-medium">AskReddit</TableCell>
                  <TableCell>98</TableCell>
                  <TableCell>42.8</TableCell>
                  <TableCell>0.31</TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </CardContent>
        </Card>
        <Card className="gradient-card card-hover">
          <CardHeader>
            <CardTitle>Top Users</CardTitle>
            <CardDescription>Most active users by post count</CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>User</TableHead>
                  <TableHead>Posts</TableHead>
                  <TableHead>Avg. Score</TableHead>
                  <TableHead>Primary Subreddit</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                <TableRow className="transition-colors hover:bg-primary/5">
                  <TableCell className="font-medium">AutoModerator</TableCell>
                  <TableCell>87</TableCell>
                  <TableCell>2.4</TableCell>
                  <TableCell>Multiple</TableCell>
                </TableRow>
                <TableRow className="transition-colors hover:bg-primary/5">
                  <TableCell className="font-medium">NewMunicipalAgenda</TableCell>
                  <TableCell>42</TableCell>
                  <TableCell>48.6</TableCell>
                  <TableCell>Anarchism</TableCell>
                </TableRow>
                <TableRow className="transition-colors hover:bg-primary/5">
                  <TableCell className="font-medium">PoliticalUser123</TableCell>
                  <TableCell>38</TableCell>
                  <TableCell>72.8</TableCell>
                  <TableCell>Politics</TableCell>
                </TableRow>
                <TableRow className="transition-colors hover:bg-primary/5">
                  <TableCell className="font-medium">TechEnthusiast</TableCell>
                  <TableCell>35</TableCell>
                  <TableCell>64.2</TableCell>
                  <TableCell>Technology</TableCell>
                </TableRow>
                <TableRow className="transition-colors hover:bg-primary/5">
                  <TableCell className="font-medium">ScienceExplorer</TableCell>
                  <TableCell>31</TableCell>
                  <TableCell>86.4</TableCell>
                  <TableCell>Science</TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
