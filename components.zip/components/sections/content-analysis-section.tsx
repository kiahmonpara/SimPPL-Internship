import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { AiSummaryBox } from "@/components/ui/summary-box"
import Image from "next/image"

export default function ContentAnalysisSection() {
  return (
    <div className="space-y-6">
      <div className="dark-section animate-fade-in">
        <AiSummaryBox
          title="Content Analysis Insights"
          content="The content includes a mix of social media posts covering various topics, with notable political and social discussions. Approximately 35% of posts contain questions, suggesting significant information-seeking behavior. Content categorized as 'Educational' receives the highest engagement, indicating a community preference for informative material. Terms related to 'freedom' and 'rights' frequently appear together, as do 'education' and 'community.' These correlations suggest conceptual relationships that shape the discourse across the analyzed subreddits."
          type="content"
        />
      </div>

      <div className="grid gap-6 md:grid-cols-2 stagger-children">
        <Card className="gradient-card card-hover">
          <CardHeader>
            <CardTitle>Word Cloud - General Content</CardTitle>
            <CardDescription>Most frequent words across all posts</CardDescription>
          </CardHeader>
          <CardContent className="flex justify-center">
            <Image
              src="/general-wordcloud.png"
              alt="General Word Cloud"
              width={500}
              height={300}
              className="rounded-md transition-all duration-300 hover:scale-[1.02]"
            />
          </CardContent>
        </Card>
        <Card className="gradient-card card-hover">
          <CardHeader>
            <CardTitle>Word Cloud - Political Content</CardTitle>
            <CardDescription>Most frequent political terms in posts</CardDescription>
          </CardHeader>
          <CardContent className="flex justify-center">
            <Image
              src="/political-wordcloud.png"
              alt="Political Word Cloud"
              width={500}
              height={300}
              className="rounded-md transition-all duration-300 hover:scale-[1.02]"
            />
          </CardContent>
        </Card>
      </div>

      <div className="light-section">
        <div className="grid gap-6 md:grid-cols-2 stagger-children">
          <Card className="gradient-card card-hover">
            <CardHeader>
              <CardTitle>Top 10 Bad Words</CardTitle>
              <CardDescription>Most frequently occurring flagged words</CardDescription>
            </CardHeader>
            <CardContent className="flex justify-center">
              <Image
                src="/bad-words.png"
                alt="Bad Words Chart"
                width={500}
                height={300}
                className="rounded-md transition-all duration-300 hover:scale-[1.02]"
              />
            </CardContent>
          </Card>
          <Card className="gradient-card card-hover">
            <CardHeader>
              <CardTitle>Top 10 Political Words</CardTitle>
              <CardDescription>Most frequently occurring political terms</CardDescription>
            </CardHeader>
            <CardContent className="flex justify-center">
              <Image
                src="/political-words.png"
                alt="Political Words Chart"
                width={500}
                height={300}
                className="rounded-md transition-all duration-300 hover:scale-[1.02]"
              />
            </CardContent>
          </Card>
        </div>
      </div>

      <Card className="gradient-card card-hover animate-fade-in">
        <CardHeader>
          <CardTitle>Content Categories</CardTitle>
          <CardDescription>Distribution of content by category</CardDescription>
        </CardHeader>
        <CardContent className="flex justify-center">
          <Image
            src="/content-distribution.png"
            alt="Content Distribution"
            width={700}
            height={300}
            className="rounded-md transition-all duration-300 hover:scale-[1.02]"
          />
        </CardContent>
      </Card>

      <AiSummaryBox
        title="Bad Words Analysis"
        content="Analysis of offensive language reveals patterns that could negatively impact community health and user experience. The frequency of flagged terms is relatively low compared to overall content volume, suggesting effective community moderation. However, certain subreddits show higher concentrations of problematic language, particularly in politically charged discussions. Implementing targeted content moderation in these areas could improve overall discourse quality."
        type="sentiment"
      />

      <AiSummaryBox
        title="Political Words Analysis"
        content="Political terminology in posts indicates polarization and suggests significant influence on user engagement patterns. Terms related to governance, rights, and social systems dominate the political discourse. Posts containing political terminology generate 35% more comments on average than non-political content, indicating higher engagement but potentially more contentious discussions. The analysis reveals distinct political vocabulary clusters that align with different ideological perspectives."
        type="content"
      />
    </div>
  )
}
