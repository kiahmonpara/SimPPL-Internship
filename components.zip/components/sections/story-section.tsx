import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { AiSummaryBox } from "@/components/ui/summary-box"

export default function StorySection() {
  return (
    <div className="space-y-6">
      <div className="dark-section animate-fade-in">
        <h2 className="text-2xl font-bold mb-4 text-center bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-pink-400">
          The Reddit Political Landscape: A Data Story
        </h2>
        <div className="text-white/90 space-y-4">
          <p className="leading-relaxed">
            Our analysis of Reddit data reveals a fascinating story about online political discourse. The data shows
            that
            <span className="font-semibold text-purple-300">
              {" "}
              political discussions are the most engaging yet polarizing{" "}
            </span>
            content across the platform.
          </p>
          <p className="leading-relaxed">
            When we look at the sentiment analysis, we see that political subreddits like r/Politics show more negative
            sentiment (-0.15) compared to science and technology subreddits which maintain positive sentiment scores
            (0.56 and 0.42 respectively).
          </p>
        </div>
      </div>

      <div className="light-section">
        <h3 className="text-xl font-bold mb-4 text-center">Key Narrative Points</h3>
        <div className="grid gap-4 md:grid-cols-3 stagger-children">
          <Card className="gradient-card card-hover">
            <CardHeader>
              <CardTitle className="bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-pink-400">
                The Bridge Users
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="leading-relaxed">
                A small group of 15 users serve as information bridges between different communities. These users post
                across multiple subreddits, creating connections between otherwise separate discussion spaces.
              </p>
            </CardContent>
          </Card>
          <Card className="gradient-card card-hover">
            <CardHeader>
              <CardTitle className="bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-pink-400">
                Weekend Positivity
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="leading-relaxed">
                Sentiment scores peak on Fridays (0.52) and Saturdays (0.48), suggesting a more positive community
                engagement during weekends when users may be more relaxed and less focused on contentious topics.
              </p>
            </CardContent>
          </Card>
          <Card className="gradient-card card-hover">
            <CardHeader>
              <CardTitle className="bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-pink-400">
                Educational Preference
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="leading-relaxed">
                Content categorized as "Educational" receives the highest engagement, indicating a community preference
                for informative material despite the prevalence of political content.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>

      <AiSummaryBox
        title="The Story Behind the Data"
        content="Our analysis tells a story of a Reddit community that values educational content but engages most actively with political discussions. The data reveals a platform where information flows between distinct communities thanks to a small group of bridge users. Weekend conversations tend to be more positive, while weekday discussions focus more on political topics with more polarized sentiment. Science-related content consistently demonstrates the highest positive sentiment, suggesting these communities maintain a more constructive discourse regardless of topic controversy."
        type="story"
      />

      <div className="dark-section">
        <h3 className="text-xl font-bold mb-4 text-center text-white">Narrative Timeline</h3>
        <div className="relative">
          <div className="absolute left-4 h-full w-0.5 bg-gradient-to-b from-purple-500 to-pink-500"></div>
          <div className="space-y-8 pl-10 stagger-children">
            <div className="transition-all duration-300 hover:translate-x-2">
              <div className="flex items-center">
                <div className="absolute -left-1 flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-purple-500 to-pink-500 text-white shadow-lg shadow-purple-500/20">
                  1
                </div>
                <h4 className="text-lg font-semibold text-white">Initial Data Collection</h4>
              </div>
              <p className="mt-2 text-white/80">
                Our journey began with collecting data from 48 active subreddits, capturing 2,853 posts from 1,274
                unique authors.
              </p>
            </div>
            <div className="transition-all duration-300 hover:translate-x-2">
              <div className="flex items-center">
                <div className="absolute -left-1 flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-blue-500 to-cyan-500 text-white shadow-lg shadow-blue-500/20">
                  2
                </div>
                <h4 className="text-lg font-semibold text-white">Content Analysis</h4>
              </div>
              <p className="mt-2 text-white/80">
                We analyzed the content using natural language processing to identify key themes, sentiment, and
                relationships between topics.
              </p>
            </div>
            <div className="transition-all duration-300 hover:translate-x-2">
              <div className="flex items-center">
                <div className="absolute -left-1 flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-pink-500 to-rose-500 text-white shadow-lg shadow-pink-500/20">
                  3
                </div>
                <h4 className="text-lg font-semibold text-white">Network Mapping</h4>
              </div>
              <p className="mt-2 text-white/80">
                We mapped the connections between subreddits and users, revealing 5 distinct communities and identifying
                key bridge users.
              </p>
            </div>
            <div className="transition-all duration-300 hover:translate-x-2">
              <div className="flex items-center">
                <div className="absolute -left-1 flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-green-500 to-emerald-500 text-white shadow-lg shadow-green-500/20">
                  4
                </div>
                <h4 className="text-lg font-semibold text-white">Insight Generation</h4>
              </div>
              <p className="mt-2 text-white/80">
                Using AI, we generated insights about the patterns in the data, revealing the story of Reddit's
                political landscape.
              </p>
            </div>
          </div>
        </div>
      </div>

      <Card className="gradient-card card-hover animate-fade-in">
        <CardHeader>
          <CardTitle>Conclusions</CardTitle>
          <CardDescription>Key takeaways from our data story</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <p className="flex items-start gap-2">
              <span className="inline-flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-purple-500 to-pink-500 text-white text-sm font-bold">
                1
              </span>
              <span>
                <strong className="text-primary">Political Polarization:</strong> Political subreddits show the most
                polarized sentiment scores, reflecting broader societal divisions.
              </span>
            </p>
            <p className="flex items-start gap-2">
              <span className="inline-flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-purple-500 to-pink-500 text-white text-sm font-bold">
                2
              </span>
              <span>
                <strong className="text-primary">Bridge Users:</strong> A small group of users play a crucial role in
                information flow across the platform.
              </span>
            </p>
            <p className="flex items-start gap-2">
              <span className="inline-flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-purple-500 to-pink-500 text-white text-sm font-bold">
                3
              </span>
              <span>
                <strong className="text-primary">Temporal Patterns:</strong> Weekend discussions are more positive than
                weekday conversations.
              </span>
            </p>
            <p className="flex items-start gap-2">
              <span className="inline-flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-purple-500 to-pink-500 text-white text-sm font-bold">
                4
              </span>
              <span>
                <strong className="text-primary">Content Preferences:</strong> Despite high engagement with political
                content, users show a preference for educational material.
              </span>
            </p>
            <p className="flex items-start gap-2">
              <span className="inline-flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-purple-500 to-pink-500 text-white text-sm font-bold">
                5
              </span>
              <span>
                <strong className="text-primary">Community Structure:</strong> The Reddit ecosystem consists of 5
                distinct communities with significant cross-posting activity.
              </span>
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
