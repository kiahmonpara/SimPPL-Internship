import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowUpRight, MessageSquare, Users } from "lucide-react"
import { AiSummaryBox } from "@/components/ui/summary-box"
import Image from "next/image"

export default function OverviewSection() {
  return (
    <div className="space-y-6">
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4 stagger-children">
        <Card className="stat-card card-hover purple">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Posts</CardTitle>
            <div className="h-4 w-4 text-primary">
              <ArrowUpRight className="h-4 w-4" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">2,853</div>
            <p className="text-xs text-muted-foreground">+12.5% from last month</p>
          </CardContent>
        </Card>
        <Card className="stat-card card-hover pink">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg. Sentiment</CardTitle>
            <div className="h-4 w-4 text-pink-500">
              <Sparkles className="h-4 w-4" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">+0.42</div>
            <p className="text-xs text-muted-foreground">+0.08 from last month</p>
          </CardContent>
        </Card>
        <Card className="stat-card card-hover blue">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Subreddits</CardTitle>
            <div className="h-4 w-4 text-blue-500">
              <MessageSquare className="h-4 w-4" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">48</div>
            <p className="text-xs text-muted-foreground">+4 from last month</p>
          </CardContent>
        </Card>
        <Card className="stat-card card-hover green">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Unique Authors</CardTitle>
            <div className="h-4 w-4 text-green-500">
              <Users className="h-4 w-4" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">1,274</div>
            <p className="text-xs text-muted-foreground">+7.2% from last month</p>
          </CardContent>
        </Card>
      </div>

      <div className="light-section animate-fade-in">
        <AiSummaryBox
          title="Overall Content Summary"
          content="The content analysis reveals several dominant themes including political discourse, educational resources, and community discussions. Political terminology appears most frequently, suggesting a strong focus on socio-political topics. Posts average 500+ characters in length, indicating detailed and substantive content rather than brief updates. Educational content tends to be the longest, while discussion posts are typically shorter but generate more comments."
          type="ai"
        />
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-7 stagger-children">
        <Card className="col-span-4 gradient-card card-hover">
          <CardHeader>
            <CardTitle>Posts Over Time</CardTitle>
            <CardDescription>Daily post volume over the past month</CardDescription>
          </CardHeader>
          <CardContent className="pl-2">
            <Image
              src="/posts-over-time.png"
              alt="Posts Over Time"
              width={800}
              height={400}
              className="rounded-md transition-all duration-300 hover:scale-[1.02]"
            />
          </CardContent>
        </Card>
        <Card className="col-span-3 gradient-card card-hover">
          <CardHeader>
            <CardTitle>Content Categories</CardTitle>
            <CardDescription>Distribution of post categories</CardDescription>
          </CardHeader>
          <CardContent>
            <Image
              src="/content-categories.png"
              alt="Content Categories"
              width={500}
              height={400}
              className="rounded-md transition-all duration-300 hover:scale-[1.02]"
            />
          </CardContent>
        </Card>
      </div>

      <div className="dark-section">
        <div className="grid gap-6 md:grid-cols-2 stagger-children">
          <Card className="gradient-card card-hover">
            <CardHeader>
              <CardTitle>Top Subreddits</CardTitle>
              <CardDescription>Most active subreddits by post count</CardDescription>
            </CardHeader>
            <CardContent className="pl-2">
              <Image
                src="/top-subreddits.png"
                alt="Top Subreddits"
                width={500}
                height={400}
                className="rounded-md transition-all duration-300 hover:scale-[1.02]"
              />
            </CardContent>
          </Card>
          <Card className="gradient-card card-hover">
            <CardHeader>
              <CardTitle>Sentiment by Day</CardTitle>
              <CardDescription>Average sentiment score by day of week</CardDescription>
            </CardHeader>
            <CardContent className="pl-2">
              <Image
                src="/sentiment-by-day.png"
                alt="Sentiment by Day"
                width={500}
                height={400}
                className="rounded-md transition-all duration-300 hover:scale-[1.02]"
              />
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

function Sparkles({ className }: { className?: string }) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
    >
      <path d="M12 3v5m4-2-1 1m-6 0-1-1m-2 4h5m-2 4 1 1m4 0 1-1m2-4h-5m-5 8 2-5 5-2-5-2-2-5-2 5-5 2 5 2z" />
    </svg>
  )
}
