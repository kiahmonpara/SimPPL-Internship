import Dashboard from "../components/dashboard.tsx"

export default function Page() {
  return <Dashboard />
}
