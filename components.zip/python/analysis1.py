import os
import json
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime
from textblob import TextBlob
import re
from collections import Counter
import nltk
nltk.download('punkt_tab')
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
import networkx as nx
import requests
from tenacity import retry, stop_after_attempt, wait_exponential
# Add Neo4j imports
from neo4j import GraphDatabase
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Create input folder if it doesn't exist
input_folder = "input"
if not os.path.exists(input_folder):
    os.makedirs(input_folder)

# Fix NLTK resource download problem
def ensure_nltk_resources():
    """
    Properly download and verify NLTK resources
    """
    nltk_data_path = os.path.join(os.path.expanduser("~"), "nltk_data")
    if not os.path.exists(nltk_data_path):
        os.makedirs(nltk_data_path)
    
    # Make sure NLTK uses the correct path
    nltk.data.path.append(nltk_data_path)
    
    # Define resources to download
    resources = [
        ('tokenizers/punkt', 'punkt'),
        ('corpora/stopwords', 'stopwords')
    ]
    
    for resource_path, resource_name in resources:
        try:
            # Check if resource exists
            if not os.path.exists(os.path.join(nltk_data_path, resource_path)):
                logger.info(f"Downloading NLTK resource: {resource_name}")
                nltk.download(resource_name, download_dir=nltk_data_path, quiet=True)
                
            # Verify resource can be loaded
            if resource_name == 'punkt':
                word_tokenize("Test sentence.")
                logger.info("NLTK punkt tokenizer verified.")
            elif resource_name == 'stopwords':
                stopwords.words('english')
                logger.info("NLTK stopwords verified.")
        except Exception as e:
            logger.error(f"Error with NLTK resource {resource_name}: {e}")
            return False
    
    return True

# Call the function to ensure NLTK resources are available
nltk_resources_available = ensure_nltk_resources()

# Add a fallback tokenizer function (keep this as backup)
def fallback_tokenize(text):
    """Simple word tokenization as fallback if NLTK fails"""
    if not isinstance(text, str):
        return []
    return text.lower().split()

# Neo4j integration functions
class Neo4jConnector:
    def __init__(self, uri="bolt://localhost:7687", user="neo4j", password="password"):
        """Initialize Neo4j connection"""
        try:
            self.driver = GraphDatabase.driver(uri, auth=(user, password))
            logger.info("Connected to Neo4j database")
            self._create_constraints_and_indexes()
        except Exception as e:
            logger.error(f"Failed to connect to Neo4j: {e}")
            self.driver = None
    
    def close(self):
        """Close the Neo4j connection"""
        if self.driver:
            self.driver.close()
            logger.info("Neo4j connection closed")
    
    def _create_constraints_and_indexes(self):
        """Create constraints and indexes for better performance"""
        with self.driver.session() as session:
            # Create constraints for unique IDs
            session.run("CREATE CONSTRAINT IF NOT EXISTS FOR (p:Post) REQUIRE p.id IS UNIQUE")
            session.run("CREATE CONSTRAINT IF NOT EXISTS FOR (u:User) REQUIRE u.name IS UNIQUE")
            session.run("CREATE CONSTRAINT IF NOT EXISTS FOR (s:Subreddit) REQUIRE s.name IS UNIQUE")
            session.run("CREATE CONSTRAINT IF NOT EXISTS FOR (d:Domain) REQUIRE d.name IS UNIQUE")
            session.run("CREATE CONSTRAINT IF NOT EXISTS FOR (k:Keyword) REQUIRE k.word IS UNIQUE")
            session.run("CREATE CONSTRAINT IF NOT EXISTS FOR (c:Category) REQUIRE c.name IS UNIQUE")
            
            # Create indexes for common lookups
            session.run("CREATE INDEX IF NOT EXISTS FOR (p:Post) ON (p.score)")
            session.run("CREATE INDEX IF NOT EXISTS FOR (p:Post) ON (p.created_utc)")
    
    def clear_database(self):
        """Clear all data from the database"""
        if not self.driver:
            logger.warning("No Neo4j connection available")
            return
            
        with self.driver.session() as session:
            session.run("MATCH (n) DETACH DELETE n")
            logger.info("Neo4j database cleared")
    
    def load_reddit_data(self, df):
        """Load processed Reddit data into Neo4j"""
        if not self.driver:
            logger.warning("No Neo4j connection available")
            return
            
        total_posts = len(df)
        logger.info(f"Loading {total_posts} posts into Neo4j...")
        
        # Process in batches for better performance
        batch_size = 100
        for i in range(0, total_posts, batch_size):
            batch_df = df.iloc[i:min(i+batch_size, total_posts)]
            self._process_batch(batch_df)
            logger.info(f"Processed {min(i+batch_size, total_posts)}/{total_posts} posts")
        
        logger.info("All data loaded into Neo4j")
    
    def _process_batch(self, batch_df):
        """Process a batch of posts"""
        with self.driver.session() as session:
            for _, row in batch_df.iterrows():
                # Create Post node
                session.run("""
                    MERGE (p:Post {id: $id})
                    SET p.title = $title,
                        p.score = $score,
                        p.comments = $comments,
                        p.created_utc = $created_utc,
                        p.sentiment = $sentiment,
                        p.subjectivity = $subjectivity
                """, {
                    'id': row['id'],
                    'title': row['title'],
                    'score': row['score'],
                    'comments': row['num_comments'],
                    'created_utc': row['created_utc'].timestamp() if isinstance(row['created_utc'], datetime) else None,
                    'sentiment': row['combined_sentiment'],
                    'subjectivity': row['combined_subjectivity']
                })
                
                # Create Author node and relationship
                session.run("""
                    MERGE (u:User {name: $author})
                    WITH u
                    MATCH (p:Post {id: $post_id})
                    MERGE (u)-[:POSTED]->(p)
                """, {
                    'author': row['author'],
                    'post_id': row['id']
                })
                
                # Create Subreddit node and relationship
                session.run("""
                    MERGE (s:Subreddit {name: $subreddit})
                    WITH s
                    MATCH (p:Post {id: $post_id})
                    MERGE (p)-[:POSTED_IN]->(s)
                """, {
                    'subreddit': row['subreddit'],
                    'post_id': row['id']
                })
                
                # Create Domain node and relationship (if domain exists)
                if 'domain' in row and row['domain']:
                    session.run("""
                        MERGE (d:Domain {name: $domain})
                        WITH d
                        MATCH (p:Post {id: $post_id})
                        MERGE (p)-[:LINKS_TO]->(d)
                    """, {
                        'domain': row['domain'],
                        'post_id': row['id']
                    })
                
                # Create Keyword nodes and relationships
                if 'keywords' in row and row['keywords']:
                    keywords = [kw.strip() for kw in row['keywords'].split(',') if kw.strip()]
                    for keyword in keywords:
                        session.run("""
                            MERGE (k:Keyword {word: $keyword})
                            WITH k
                            MATCH (p:Post {id: $post_id})
                            MERGE (p)-[:HAS_KEYWORD]->(k)
                        """, {
                            'keyword': keyword,
                            'post_id': row['id']
                        })
                
                # Create Category nodes and relationships
                if 'categories' in row and row['categories']:
                    categories = [cat.strip() for cat in row['categories'].split(',') if cat.strip()]
                    for category in categories:
                        session.run("""
                            MERGE (c:Category {name: $category})
                            WITH c
                            MATCH (p:Post {id: $post_id})
                            MERGE (p)-[:BELONGS_TO]->(c)
                        """, {
                            'category': category,
                            'post_id': row['id']
                        })
                
                # Create Crosspost relationship if applicable
                if 'is_crosspost' in row and row['is_crosspost'] and 'crosspost_parent' in row and row['crosspost_parent']:
                    session.run("""
                        MATCH (p1:Post {id: $child_id})
                        MATCH (p2:Post {id: $parent_id})
                        MERGE (p1)-[:CROSSPOSTED_FROM]->(p2)
                    """, {
                        'child_id': row['id'],
                        'parent_id': row['crosspost_parent'].split('_')[1] if '_' in row['crosspost_parent'] else row['crosspost_parent']
                    })
    
    def generate_graph_insights(self):
        """Generate insights based on graph relationships"""
        if not self.driver:
            logger.warning("No Neo4j connection available")
            return {}
        
        insights = {}
        
        with self.driver.session() as session:
            # Most central subreddits (PageRank)
            result = session.run("""
                CALL gds.pageRank.stream('subreddit_graph')
                YIELD nodeId, score
                MATCH (s:Subreddit) WHERE id(s) = nodeId
                RETURN s.name AS subreddit, score
                ORDER BY score DESC
                LIMIT 5
            """)
            central_subreddits = [record["subreddit"] for record in result]
            if central_subreddits:
                insights["central_subreddits"] = central_subreddits
            
            # Find subreddit communities
            result = session.run("""
                CALL gds.louvain.stream('subreddit_graph')
                YIELD nodeId, communityId
                MATCH (s:Subreddit) WHERE id(s) = nodeId
                RETURN communityId, collect(s.name) AS subreddits
                ORDER BY size(subreddits) DESC
                LIMIT 3
            """)
            communities = [record["subreddits"] for record in result]
            if communities:
                insights["subreddit_communities"] = communities
            
            # Find influential users
            result = session.run("""
                MATCH (u:User)-[:POSTED]->(p:Post)
                WITH u, count(p) AS post_count, sum(p.score) AS total_score
                RETURN u.name AS user, post_count, total_score
                ORDER BY total_score DESC
                LIMIT 5
            """)
            influential_users = [f"{record['user']} (Score: {record['total_score']})" for record in result]
            if influential_users:
                insights["influential_users"] = influential_users
            
            # Find correlated keywords
            result = session.run("""
                MATCH (k1:Keyword)<-[:HAS_KEYWORD]-(p:Post)-[:HAS_KEYWORD]->(k2:Keyword)
                WHERE k1.word < k2.word
                WITH k1.word AS keyword1, k2.word AS keyword2, count(p) AS post_count
                WHERE post_count > 2
                RETURN keyword1, keyword2, post_count
                ORDER BY post_count DESC
                LIMIT 10
            """)
            keyword_pairs = [f"{record['keyword1']} - {record['keyword2']} ({record['post_count']} posts)" for record in result]
            if keyword_pairs:
                insights["correlated_keywords"] = keyword_pairs
        
        return insights

    def create_graph_visualization(self, filename):
        """Create a visualization of the Reddit graph structure"""
        if not self.driver:
            logger.warning("No Neo4j connection available")
            return
        
        # This would normally use Neo4j's graph visualization, but we'll use NetworkX as a substitute
        G = nx.DiGraph()
        
        with self.driver.session() as session:
            # Get subreddits
            result = session.run("MATCH (s:Subreddit) RETURN s.name AS name, id(s) AS id")
            for record in result:
                G.add_node(record["name"], type="subreddit")
            
            # Get top authors
            result = session.run("MATCH (u:User) RETURN u.name AS name LIMIT 20")
            for record in result:
                G.add_node(record["name"], type="user")
            
            # Get user-subreddit connections
            result = session.run("""
                MATCH (u:User)-[:POSTED]->(:Post)-[:POSTED_IN]->(s:Subreddit)
                RETURN u.name AS user, s.name AS subreddit, count(*) AS strength
                LIMIT 100
            """)
            for record in result:
                G.add_edge(record["user"], record["subreddit"], weight=record["strength"], type="posted_in")
        
        # Create visualization
        plt.figure(figsize=(15, 12))
        
        # Define node positions
        pos = nx.spring_layout(G, k=0.3, iterations=50)
        
        # Draw subreddit nodes
        subreddit_nodes = [node for node, attr in G.nodes(data=True) if attr.get('type') == 'subreddit']
        nx.draw_networkx_nodes(G, pos, nodelist=subreddit_nodes, node_color='lightblue', 
                              node_size=300, alpha=0.8)
        
        # Draw user nodes
        user_nodes = [node for node, attr in G.nodes(data=True) if attr.get('type') == 'user']
        nx.draw_networkx_nodes(G, pos, nodelist=user_nodes, node_color='lightgreen', 
                              node_size=200, alpha=0.7)
        
        # Draw edges
        nx.draw_networkx_edges(G, pos, width=0.5, alpha=0.5, edge_color='gray', arrows=True)
        
        # Add labels
        nx.draw_networkx_labels(G, pos, font_size=10)
        
        plt.title("Reddit Network: Users and Subreddits")
        plt.axis('off')
        plt.tight_layout()
        plt.savefig(os.path.join(input_folder, filename))
        plt.close()
        
        logger.info(f"Created graph visualization: {filename}")
        
        # Return network metrics
        return {
            "node_count": G.number_of_nodes(),
            "edge_count": G.number_of_edges(),
            "avg_degree": sum(dict(G.degree()).values()) / G.number_of_nodes(),
            "density": nx.density(G)
        }

# Load the JSON data - modified to better handle errors
def load_data(file_path):
    try:
        logger.info(f"Attempting to load data from {file_path}")
        with open(file_path, 'r') as file:
            data = json.load(file)
        logger.info(f"Successfully loaded data with {len(data)} records")
        return data
    except FileNotFoundError:
        logger.warning(f"File not found: {file_path}")
    except json.JSONDecodeError:
        logger.error(f"Invalid JSON format in {file_path}")
    except Exception as e:
        logger.error(f"Error loading data: {e}")
    
    # Create a small sample from the provided data
    logger.info("Using sample data instead")
    sample_data = [
        {"kind": "t3", "data": {"subreddit": "Anarchism", "author": "AutoModerator", "title": "What Are You Reading/Book Club Tuesday", "created_utc": 1739858460.0, "score": 2, "ups": 2, "downs": 0, "num_comments": 1}},
        {"kind": "t3", "data": {"subreddit": "Anarchism", "author": "NewMunicipalAgenda", "title": "\"WTF is Social Ecology?\" by Usufruct Collective", "created_utc": 1739818025.0, "score": 48, "ups": 48, "downs": 0, "num_comments": 2}}
    ]
    return sample_data

# Improved function for text analysis
def extract_keywords(text, num_keywords=5):
    """Extract keywords with better error handling and using NLTK resources properly"""
    if not isinstance(text, str) or not text.strip():
        return []
    
    # Use NLTK tokenizer if available, otherwise fallback
    if nltk_resources_available:
        try:
            # Properly tokenize text
            words = word_tokenize(clean_text(text))
            # Get stopwords from NLTK
            stop_words = set(stopwords.words('english'))
            # Filter words
            filtered_words = [word for word in words if word not in stop_words and len(word) > 2]
            # Count word frequencies
            word_counts = Counter(filtered_words)
            return word_counts.most_common(num_keywords)
        except Exception as e:
            logger.error(f"Error using NLTK for keyword extraction: {e}")
    
    # Use fallback tokenizer
    logger.warning("Using fallback tokenizer for keywords extraction")
    words = fallback_tokenize(clean_text(text))
    
    # Basic English stopwords as fallback
    stop_words = {'a', 'an', 'the', 'and', 'or', 'but', 'if', 'because', 'as', 'what',
                 'when', 'where', 'how', 'all', 'any', 'both', 'each', 'few', 'more',
                 'most', 'some', 'such', 'no', 'nor', 'not', 'only', 'own', 'same', 'so',
                 'than', 'too', 'very', 'can', 'will', 'just', 'should', 'now', 'to', 'of',
                 'for', 'in', 'on', 'at', 'by', 'with', 'about', 'against', 'between',
                 'into', 'through', 'during', 'before', 'after', 'above', 'below', 'from',
                 'up', 'down', 'is', 'am', 'are', 'was', 'were', 'be', 'been', 'being',
                 'have', 'has', 'had', 'having', 'do', 'does', 'did', 'doing', 'this',
                 'that', 'these', 'those', 'they', 'them', 'their', 'his', 'her', 'its'}
    
    filtered_words = [word for word in words if word not in stop_words and len(word) > 2]
    word_counts = Counter(filtered_words)
    return word_counts.most_common(num_keywords)

# Keep other utility functions from the original code
def clean_text(text):
    if not isinstance(text, str):
        return ""
    text = re.sub(r'[^\w\s]', '', text.lower())
    return text

def get_sentiment(text):
    if not isinstance(text, str) or not text.strip():
        return 0.0
    analysis = TextBlob(text)
    return analysis.sentiment.polarity

def get_subjectivity(text):
    if not isinstance(text, str) or not text.strip():
        return 0.0
    analysis = TextBlob(text)
    return analysis.sentiment.subjectivity

def categorize_content(title, selftext):
    """Simple content categorization based on keywords"""
    categories = []
    combined_text = (title + " " + selftext).lower() if isinstance(selftext, str) else title.lower()
    
    # Define category keywords
    politics_keywords = ['political', 'government', 'democracy', 'election', 'vote', 'policy', 'freedom', 'rights', 'anarchism']
    
    educational_keywords = ['learn', 'education', 'book', 'reading', 'guide', 'tutorial', 'explain', 'understanding', 'wtf is']
    
    discussion_keywords = ['discussion', 'debate', 'opinion', 'thoughts', 'what are you', 'what do you think', 'question']
    
    # Check for matches
    if any(keyword in combined_text for keyword in politics_keywords):
        categories.append('Politics')
    
    if any(keyword in combined_text for keyword in educational_keywords):
        categories.append('Educational')
    
    if any(keyword in combined_text for keyword in discussion_keywords):
        categories.append('Discussion')
    
    # If no categories matched, label as 'Other'
    if not categories:
        categories.append('Other')
    
    return categories

# Function to generate content insights using Gemini API
def generate_content_insights(df, api_key=None):
    """
    Generate advanced insights on Reddit content using the Gemini API.
    
    Args:
        df: Pandas DataFrame containing processed Reddit posts
        api_key: API key for the Gemini service
    
    Returns:
        dict: Dictionary containing different analysis results
    """
    # If no API key is provided, return a basic analysis
    if not api_key:
        logger.info("No API key provided, using basic analysis only.")
        return generate_fallback_analysis(df)
    
    # Prepare sample data for analysis
    titles = df['title'].tolist()[:20]  # Limit to 20 titles to avoid token limits
    combined_titles = "\n".join([f"- {title}" for title in titles])
    
    # Sample content for deeper analysis if available
    if 'selftext' in df.columns:
        content_samples = []
        for text in df['selftext'].dropna().head(5):
            if isinstance(text, str) and len(text) > 10:
                # Truncate very long texts
                content_samples.append(text[:500] + "..." if len(text) > 500 else text)
        combined_content = "\n\n".join(content_samples)
    else:
        combined_content = "No content available for analysis."
    
    # Prepare prompts for different analysis types
    analysis_prompts = {
        "thematic": f"Identify 3-5 key themes or topics from these Reddit post titles:\n{combined_titles}",
        "sentiment_context": f"Beyond basic sentiment scores, analyze the emotional tone of these Reddit posts and explain possible context:\n{combined_titles}",
        "user_intent": f"Categorize the apparent user intent behind these Reddit posts (e.g., seeking information, sharing resources, community building):\n{combined_titles}",
        "content_depth": f"Analyze the depth and substance of these sample Reddit posts:\n{combined_content}"
    }
    
    # Collect results
    insights = {}
    
    # Execute analyses
    for analysis_type, prompt in analysis_prompts.items():
        try:
            result = call_llm_api(prompt, api_key)
            insights[analysis_type] = result
        except Exception as e:
            logger.error(f"Error in {analysis_type} analysis: {e}")
            insights[analysis_type] = f"Analysis failed: {str(e)}"
    
    return insights

@retry(stop=stop_after_attempt(3), wait=wait_exponential(min=1, max=10))
def call_llm_api(prompt, api_key):
    """
    Call the Gemini API with retry logic
    """
    headers = {
        "Content-Type": "application/json"
    }
    
    payload = {
        "contents": [{
            "parts": [{
                "text": prompt
            }]
        }]
    }
    
    # Gemini API URL with your key
    api_url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key={api_key}"
    
    response = requests.post(
        api_url,
        headers=headers,
        data=json.dumps(payload)
    )
    
    if response.status_code == 200:
        response_json = response.json()
        # Extract text from Gemini response structure
        if 'candidates' in response_json and len(response_json['candidates']) > 0:
            if 'content' in response_json['candidates'][0]:
                content = response_json['candidates'][0]['content']
                if 'parts' in content and len(content['parts']) > 0:
                    return content['parts'][0]['text']
        return "No text content found in response"
    else:
        raise Exception(f"API call failed with status {response.status_code}: {response.text}")

def generate_fallback_analysis(df):
    """Generate basic insights without using an LLM API"""
    insights = {}
    
    # Basic thematic analysis using categories
    if 'categories' in df.columns:
        category_counts = df['categories'].str.split(', ').explode().value_counts()
        insights["thematic"] = f"Most common categories in posts: {', '.join(category_counts.index[:3])}"
    else:
        insights["thematic"] = "No category information available."
    
    # Basic sentiment context
    avg_sentiment = df['combined_sentiment'].mean() if 'combined_sentiment' in df.columns else 0
    sentiment_description = "positive" if avg_sentiment > 0.1 else "negative" if avg_sentiment < -0.1 else "neutral"
    insights["sentiment_context"] = f"Posts have an overall {sentiment_description} tone with average sentiment score of {avg_sentiment:.2f}."
    
    # Basic user intent analysis
    has_questions = df['title'].str.contains(r'\?').mean() if 'title' in df.columns else 0
    insights["user_intent"] = f"Approximately {has_questions*100:.1f}% of posts contain questions, suggesting information seeking behavior."
    
    # Basic content depth analysis
    if 'selftext' in df.columns:
        avg_length = df['selftext'].str.len().mean()
        insights["content_depth"] = f"Average post length is {avg_length:.0f} characters, suggesting {'detailed' if avg_length > 500 else 'brief'} content."
    else:
        insights["content_depth"] = "No content text available for analysis."
    
    return insights

# Function to format insights for the report
def format_llm_insights(insights):
    """Format the LLM insights for inclusion in the final report"""
    if not insights:
        return "No AI-enhanced insights available."
    
    formatted = "## AI-Enhanced Content Insights\n\n"
    
    if "thematic" in insights:
        formatted += "### Key Themes\n" + insights["thematic"] + "\n\n"
    
    if "sentiment_context" in insights:
        formatted += "### Sentiment Context\n" + insights["sentiment_context"] + "\n\n"
    
    if "user_intent" in insights:
        formatted += "### User Intent Analysis\n" + insights["user_intent"] + "\n\n"
    
    if "content_depth" in insights:
        formatted += "### Content Depth\n" + insights["content_depth"] + "\n\n"
    
    return formatted

# Format Neo4j insights for the report
def format_neo4j_insights(insights):
    """Format the Neo4j graph insights for the report"""
    if not insights:
        return "No graph-based insights available."
    
    formatted = "## Graph-Based Relationship Insights\n\n"
    
    if "central_subreddits" in insights:
        formatted += "### Most Central Subreddits\n"
        formatted += "These subreddits have the most influence in the network:\n"
        for subreddit in insights["central_subreddits"]:
            formatted += f"- {subreddit}\n"
        formatted += "\n"
    
    if "subreddit_communities" in insights:
        formatted += "### Subreddit Communities\n"
        formatted += "These groups of subreddits form distinct communities:\n"
        for i, community in enumerate(insights["subreddit_communities"]):
            formatted += f"**Community {i+1}**: {', '.join(community)}\n"
        formatted += "\n"
    
    if "influential_users" in insights:
        formatted += "### Most Influential Users\n"
        formatted += "These users have the most impact across subreddits:\n"
        for user in insights["influential_users"]:
            formatted += f"- {user}\n"
        formatted += "\n"
    
    if "correlated_keywords" in insights:
        formatted += "### Correlated Keywords\n"
        formatted += "These keyword pairs frequently appear together:\n"
        for pair in insights["correlated_keywords"]:
            formatted += f"- {pair}\n"
        formatted += "\n"
    
    return formatted

# Main execution

# Try to load data from input.json or use embedded sample data
try:
    data = load_data('input.json')
except:
    logger.warning("Could not load data from input.json, using sample data")
    # Sample data defined in load_data function will be used

# Process the data
posts_data = []
for post in data:
    if 'data' in post:
        post_data = post['data']
        
        # Convert UTC timestamp to datetime
        created_utc = post_data.get('created_utc', 0)
        created_datetime = datetime.utcfromtimestamp(created_utc) if created_utc else None
        
        # Get post text content
        title = post_data.get('title', '')
        selftext = post_data.get('selftext', '')
        
        # Calculate sentiment
        title_sentiment = get_sentiment(title)
        content_sentiment = get_sentiment(selftext)
        combined_sentiment = (title_sentiment + content_sentiment) / 2 if selftext else title_sentiment
        
        # Calculate subjectivity
        title_subjectivity = get_subjectivity(title)
        content_subjectivity = get_subjectivity(selftext)
        combined_subjectivity = (title_subjectivity + content_subjectivity) / 2 if selftext else title_subjectivity
        
        # Extract keywords
        try:
            keywords = extract_keywords(title + " " + selftext if selftext else title)
        except Exception as e:
            print(f"Error extracting keywords: {e}")
            keywords = []
        
        # Categorize content
        categories = categorize_content(title, selftext)
        
        # Crosspost data
        is_crosspost = 'crosspost_parent' in post_data
        crosspost_parent = post_data.get('crosspost_parent', '')
        
        # Compile data dictionary
        processed_data = {
            'id': post_data.get('id', ''),
            'subreddit': post_data.get('subreddit', ''),
            'author': post_data.get('author', ''),
            'title': title,
            'selftext': selftext,
            'created_utc': created_datetime,
            'score': post_data.get('score', 0),
            'ups': post_data.get('ups', 0),
            'downs': post_data.get('downs', 0),
            'upvote_ratio': post_data.get('upvote_ratio', 0),
            'num_comments': post_data.get('num_comments', 0),
            'title_sentiment': title_sentiment,
            'content_sentiment': content_sentiment,
            'combined_sentiment': combined_sentiment,
            'title_subjectivity': title_subjectivity,
            'content_subjectivity': content_subjectivity,
            'combined_subjectivity': combined_subjectivity,
            'keywords': ', '.join([kw[0] for kw in keywords]),
            'categories': ', '.join(categories),
            'is_crosspost': is_crosspost,
            'crosspost_parent': crosspost_parent,
            'over_18': post_data.get('over_18', False),
            'stickied': post_data.get('stickied', False),
            'domain': post_data.get('domain', ''),
            'url': post_data.get('url', '')
        }
        
        posts_data.append(processed_data)

# Convert to DataFrame for analysis
df = pd.DataFrame(posts_data)

# Add derived columns for analysis
if 'created_utc' in df.columns and not df['created_utc'].isnull().all():
    df['date'] = df['created_utc'].dt.date
    df['day_of_week'] = df['created_utc'].dt.day_name()
    df['hour_of_day'] = df['created_utc'].dt.hour

# Save processed data
try:
    df.to_csv(os.path.join(input_folder, 'processed_posts.csv'), index=False)
    print(f"Processed data saved to {os.path.join(input_folder, 'processed_posts.csv')}")
except Exception as e:
    print(f"Error saving processed data: {e}")

# Generate LLM insights
# For Gemini, just pass your API key directly
gemini_api_key = "AIzaSyDVFjlgmZdy9a7bmmg3-FVA2eE_V3qp2tM"  # Your API key
try:
    llm_insights = generate_content_insights(df, api_key=gemini_api_key)
    llm_insights_formatted = format_llm_insights(llm_insights)
    print("Generated AI insights successfully")
except Exception as e:
    print(f"Error generating AI insights: {e}")
    llm_insights_formatted = "Error generating AI insights. Using basic analysis only."

# VISUALIZATIONS AND ANALYSIS

# Function to safely create visualizations
def safe_create_visualization(visualization_func, filename, *args, **kwargs):
    """Create visualizations with error handling"""
    try:
        visualization_func(*args, **kwargs)
        plt.savefig(os.path.join(input_folder, filename))
        plt.close()
        print(f"Created visualization: {filename}")
    except Exception as e:
        print(f"Error creating {filename}: {e}")
        plt.close()

# 1. Time-based analysis (if date data is available)
if 'date' in df.columns and not df['date'].isnull().all():
    # Posts per day
    posts_per_day = df.groupby('date').size()
    
    if not posts_per_day.empty:
        def plot_posts_per_day():
            plt.figure(figsize=(10, 6))
            posts_per_day.plot(kind='line', marker='o')
            plt.title('Posts Per Day')
            plt.xlabel('Date')
            plt.ylabel('Number of Posts')
            plt.grid(True)
            plt.xticks(rotation=45)
            plt.tight_layout()
        
        safe_create_visualization(plot_posts_per_day, 'posts_per_day.png')
    
    # Posts by hour of day (activity pattern)
    if 'hour_of_day' in df.columns:
        posts_by_hour = df.groupby('hour_of_day').size()
        
        if not posts_by_hour.empty:
            def plot_posts_by_hour():
                plt.figure(figsize=(10, 6))
                posts_by_hour.plot(kind='bar')
                plt.title('Posts by Hour of Day')
                plt.xlabel('Hour (UTC)')
                plt.ylabel('Number of Posts')
                plt.grid(axis='y')
                plt.tight_layout()
            
            safe_create_visualization(plot_posts_by_hour, 'posts_by_hour.png')
            
    # Posts by day of week
    if 'day_of_week' in df.columns:
        # Order days of week
        ordered_days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
        posts_by_day = df.groupby('day_of_week').size()
        
        # Reindex to get the correct order
        if not posts_by_day.empty:
            try:
                posts_by_day = posts_by_day.reindex(ordered_days)
            except:
                pass  # If reindexing fails, use the original order
            
            def plot_posts_by_day():
                plt.figure(figsize=(10, 6))
                posts_by_day.plot(kind='bar')
                plt.title('Posts by Day of Week')
                plt.xlabel('Day')
                plt.ylabel('Number of Posts')
                plt.grid(axis='y')
                plt.tight_layout()
            
            safe_create_visualization(plot_posts_by_day, 'posts_by_day.png')

# 2. User analysis
user_stats = df['author'].value_counts()

# Save top users to CSV
try:
    user_stats.to_csv(os.path.join(input_folder, 'top_users.csv'))
    print(f"Saved top users data to {os.path.join(input_folder, 'top_users.csv')}")
except Exception as e:
    print(f"Error saving top users data: {e}")

# Plot top 10 users
if not user_stats.empty and len(user_stats) > 0:
    def plot_top_users():
        plt.figure(figsize=(12, 6))
        user_stats.head(min(10, len(user_stats))).plot(kind='bar')
        plt.title('Top Most Active Users')
        plt.xlabel('User')
        plt.ylabel('Number of Posts')
        plt.xticks(rotation=45)
        plt.tight_layout()
    
    safe_create_visualization(plot_top_users, 'top_users.png')

# 3. Subreddit analysis
subreddit_stats = df['subreddit'].value_counts()

# Save subreddit stats to CSV
try:
    subreddit_stats.to_csv(os.path.join(input_folder, 'subreddit_stats.csv'))
    print(f"Saved subreddit stats to {os.path.join(input_folder, 'subreddit_stats.csv')}")
except Exception as e:
    print(f"Error saving subreddit stats: {e}")

# Plot top subreddits
if not subreddit_stats.empty and len(subreddit_stats) > 0:
    def plot_top_subreddits():
        plt.figure(figsize=(12, 6))
        subreddit_stats.head(min(10, len(subreddit_stats))).plot(kind='bar')
        plt.title('Top Subreddits')
        plt.xlabel('Subreddit')
        plt.ylabel('Number of Posts')
        plt.xticks(rotation=45)
        plt.tight_layout()
    
    safe_create_visualization(plot_top_subreddits, 'top_subreddits.png')

# 4. Sentiment analysis visualizations
def plot_sentiment_distributions():
    plt.figure(figsize=(14, 6))
    
    # Title sentiment distribution
    plt.subplot(1, 2, 1)
    sns.histplot(df['title_sentiment'], kde=True, color='blue')
    plt.title('Title Sentiment Distribution')
    plt.xlabel('Sentiment (-1 to 1)')
    plt.ylabel('Frequency')
    plt.grid(True, alpha=0.3)
    
    # Content sentiment distribution (if available)
    if 'content_sentiment' in df.columns and not df['content_sentiment'].isnull().all():
        plt.subplot(1, 2, 2)
        sns.histplot(df['content_sentiment'], kde=True, color='green')
        plt.title('Content Sentiment Distribution')
        plt.xlabel('Sentiment (-1 to 1)')
        plt.ylabel('Frequency')
        plt.grid(True, alpha=0.3)
    
    plt.tight_layout()

safe_create_visualization(plot_sentiment_distributions, 'sentiment_distribution.png')

# 5. Advanced Sentiment vs. Engagement Analysis
def plot_sentiment_engagement():
    plt.figure(figsize=(14, 10))
    
    # Sentiment vs. Score
    plt.subplot(2, 2, 1)
    plt.scatter(df['combined_sentiment'], df['score'], alpha=0.6)
    plt.title('Sentiment vs. Post Score')
    plt.xlabel('Sentiment (-1 to 1)')
    plt.ylabel('Score')
    plt.grid(True, alpha=0.3)
    
    # Sentiment vs. Comments
    plt.subplot(2, 2, 2)
    plt.scatter(df['combined_sentiment'], df['num_comments'], alpha=0.6)
    plt.title('Sentiment vs. Number of Comments')
    plt.xlabel('Sentiment (-1 to 1)')
    plt.ylabel('Number of Comments')
    plt.grid(True, alpha=0.3)
    
    # Subjectivity vs. Score
    plt.subplot(2, 2, 3)
    plt.scatter(df['combined_subjectivity'], df['score'], alpha=0.6)
    plt.title('Subjectivity vs. Post Score')
    plt.xlabel('Subjectivity (0 to 1)')
    plt.ylabel('Score')
    plt.grid(True, alpha=0.3)
    
    # Subjectivity vs. Comments
    plt.subplot(2, 2, 4)
    plt.scatter(df['combined_subjectivity'], df['num_comments'], alpha=0.6)
    plt.title('Subjectivity vs. Number of Comments')
    plt.xlabel('Subjectivity (0 to 1)')
    plt.ylabel('Number of Comments')
    plt.grid(True, alpha=0.3)
    
    plt.tight_layout()

safe_create_visualization(plot_sentiment_engagement, 'sentiment_engagement_analysis.png')

# 6. Content Category Analysis
if 'categories' in df.columns:
    # Extract all categories from the comma-separated lists
    all_categories = []
    for cats in df['categories'].str.split(', '):
        if isinstance(cats, list):
            all_categories.extend(cats)
    
    # Count occurrences of each category
    category_counts = Counter(all_categories)
    
    if category_counts:
        def plot_categories():
            plt.figure(figsize=(10, 6))
            plt.bar(category_counts.keys(), category_counts.values())
            plt.title('Content Categories Distribution')
            plt.xlabel('Category')
            plt.ylabel('Count')
            plt.xticks(rotation=45)
            plt.tight_layout()
        
        safe_create_visualization(plot_categories, 'content_categories.png')
        
        # Save categories to CSV
        try:
            pd.DataFrame(list(category_counts.items()), columns=['Category', 'Count']).to_csv(
                os.path.join(input_folder, 'category_distribution.csv'), index=False)
            print(f"Saved category distribution to {os.path.join(input_folder, 'category_distribution.csv')}")
        except Exception as e:
            print(f"Error saving category distribution: {e}")

# 7. Keyword analysis
if 'keywords' in df.columns:
    # Extract all keywords from the comma-separated lists
    all_keywords = []
    for kws in df['keywords'].str.split(', '):
        if isinstance(kws, list):
            all_keywords.extend([k for k in kws if k])  # Filter out empty strings
    
    # Count occurrences of each keyword
    keyword_counts = Counter(all_keywords)
    
    if keyword_counts:
        def plot_keywords():
            plt.figure(figsize=(12, 6))
            # Get top keywords (at most 15, but may be fewer)
            top_keywords = dict(keyword_counts.most_common(min(15, len(keyword_counts))))
            plt.bar(top_keywords.keys(), top_keywords.values())
            plt.title('Top Keywords')
            plt.xlabel('Keyword')
            plt.ylabel('Count')
            plt.xticks(rotation=45)
            plt.tight_layout()
        
        safe_create_visualization(plot_keywords, 'top_keywords.png')
        
        # Save keywords to CSV
        try:
            pd.DataFrame(list(keyword_counts.items()), columns=['Keyword', 'Count']).to_csv(
                os.path.join(input_folder, 'keyword_distribution.csv'), index=False)
            print(f"Saved keyword distribution to {os.path.join(input_folder, 'keyword_distribution.csv')}")
        except Exception as e:
            print(f"Error saving keyword distribution: {e}")

# 8. Crosspost Analysis
if 'is_crosspost' in df.columns:
    crosspost_count = df['is_crosspost'].sum()
    direct_post_count = len(df) - crosspost_count
    
    if crosspost_count > 0 or direct_post_count > 0:
        def plot_crosspost_ratio():
            plt.figure(figsize=(8, 8))
            plt.pie([direct_post_count, crosspost_count], 
                    labels=['Direct Posts', 'Crossposts'],
                    autopct='%1.1f%%',
                    colors=['royalblue', 'lightcoral'],
                    startangle=90,
                    explode=(0, 0.1))
            plt.title('Direct Posts vs. Crossposts')
            plt.axis('equal')
            plt.tight_layout()
        
        safe_create_visualization(plot_crosspost_ratio, 'crosspost_analysis.png')
        
        # Create a network graph of crosspost relationships between subreddits (if there are crossposts)
        if crosspost_count > 0:
            try:
                # Get original and crossposted subreddits
                crosspost_df = df[df['is_crosspost'] == True].copy()
                if not crosspost_df.empty:
                    # Create a graph
                    G = nx.DiGraph()
                    for subreddit in df['subreddit'].unique():
                        G.add_node(subreddit)
                    
                    # Add edges between subreddits that have crossposts
                    for _, row in crosspost_df.iterrows():
                        target_subreddit = row['subreddit']
                        G.add_edge("Source", target_subreddit, weight=1)
                    
                    def plot_crosspost_network():
                        plt.figure(figsize=(10, 8))
                        pos = nx.spring_layout(G)
                        nx.draw(G, pos, with_labels=True, node_color='skyblue', node_size=1500, 
                                edge_color='gray', linewidths=1, font_size=10, arrows=True)
                        plt.title('Crosspost Network Between Subreddits')
                        plt.tight_layout()
                    
                    safe_create_visualization(plot_crosspost_network, 'crosspost_network.png')
            except Exception as e:
                print(f"Could not create crosspost network graph: {e}")

# 9. Domain Analysis
if 'domain' in df.columns and not df['domain'].isnull().all():
    domain_stats = df['domain'].value_counts()
    
    # Save domain stats to CSV
    try:
        domain_stats.to_csv(os.path.join(input_folder, 'domain_stats.csv'))
        print(f"Saved domain stats to {os.path.join(input_folder, 'domain_stats.csv')}")
    except Exception as e:
        print(f"Error saving domain stats: {e}")
    
    # Plot top domains
    if not domain_stats.empty and len(domain_stats) > 0:
        def plot_top_domains():
            plt.figure(figsize=(12, 6))
            domain_stats.head(min(10, len(domain_stats))).plot(kind='bar')
            plt.title('Top Domains')
            plt.xlabel('Domain')
            plt.ylabel('Count')
            plt.xticks(rotation=45)
            plt.tight_layout()
    plt.savefig(os.path.join(input_folder, 'top_domains.png'))

# 10. Top posts analysis
top_posts = df.nlargest(10, 'score')[['title', 'author', 'subreddit', 'score', 'num_comments']]
top_posts.to_csv(os.path.join(input_folder, 'top_posts.csv'), index=False)

# Plot top 5 posts
plt.figure(figsize=(12, 6))
top_5 = df.nlargest(5, 'score')
plt.barh(top_5['title'], top_5['score'], color='orange')
plt.xlabel('Score')
plt.ylabel('Post Title')
plt.title('Top 5 Posts by Score')
plt.grid(axis='x', linestyle='--', alpha=0.7)
plt.gca().invert_yaxis()  # Highest score at the top
plt.tight_layout()
plt.savefig(os.path.join(input_folder, 'top_5_posts.png'))

# Define helper function to safely try operations
def try_value(func, default="N/A"):
    try:
        return func()
    except (TypeError, ValueError, KeyError, IndexError):
        return default

# 11. Generate comprehensive analysis report
report = f"""# Reddit Data Analysis Report

## Overview
- **Total Posts Analyzed:** {len(df)}
- **Date Range:** {df['date'].min() if 'date' in df.columns and not df['date'].isnull().all() else 'N/A'} to {df['date'].max() if 'date' in df.columns and not df['date'].isnull().all() else 'N/A'}
- **Total Subreddits:** {df['subreddit'].nunique()}
- **Total Authors:** {df['author'].nunique()}

{llm_insights_formatted}

## Content Analysis
- **Average Sentiment:** {df['combined_sentiment'].mean():.2f} (scale: -1 to 1)
- **Average Subjectivity:** {df['combined_subjectivity'].mean():.2f} (scale: 0 to 1)
- **Most Common Content Categories:** {', '.join([cat for cat, count in Counter(all_categories).most_common(3)]) if 'all_categories' in locals() else 'N/A'}

## Engagement Metrics
- **Average Score:** {df['score'].mean():.2f}
- **Average Comments:** {df['num_comments'].mean():.2f}
- **Average Upvote Ratio:** {f"{df['upvote_ratio'].mean():.2f}" if 'upvote_ratio' in df.columns else 'N/A'}

## Top Subreddits
{subreddit_stats.head(5).to_string()}

## Top Authors
{user_stats.head(5).to_string()}

## Top Posts
{top_posts[['title', 'score', 'author']].head(5).to_string()}

## Sentiment Analysis
- **Most Positive Post:** "{df.loc[df['combined_sentiment'].idxmax(), 'title']}" (Sentiment: {df['combined_sentiment'].max():.2f})
- **Most Negative Post:** "{df.loc[df['combined_sentiment'].idxmin(), 'title']}" (Sentiment: {df['combined_sentiment'].min():.2f})

## Key Findings
1. Content sentiment averages {df['combined_sentiment'].mean():.2f}, indicating an overall {'positive' if df['combined_sentiment'].mean() > 0 else 'negative' if df['combined_sentiment'].mean() < 0 else 'neutral'} tone.
2. {'Posts with higher sentiment scores tend to receive more upvotes.' if df['combined_sentiment'].corr(df['score']) > 0.2 else 'There is no strong correlation between sentiment and post score.'}
3. The most active day for posting is {df['day_of_week'].mode()[0] if 'day_of_week' in df.columns and not df.empty else 'N/A'}.
4. {'Crossposts account for ' + str(round(crosspost_count/len(df)*100, 1)) + '% of all posts.' if 'crosspost_count' in locals() else ''}

## Recommendations
1. Best time to post: {try_value(lambda: df.groupby('hour_of_day').mean()['score'].idxmax(), 'N/A')} UTC on {try_value(lambda: df.groupby('day_of_week').mean()['score'].idxmax(), 'N/A')}
2. Content with {try_value(lambda: 'positive' if df.groupby('combined_sentiment').mean()['score'].idxmax() > 0 else 'negative' if df.groupby('combined_sentiment').mean()['score'].idxmax() < 0 else 'neutral', 'neutral')} sentiment tends to perform better.
3. Most engaging content categories: {try_value(lambda: ', '.join([cat for cat, _ in sorted(zip(df['categories'].unique(), [df[df['categories'] == cat]['score'].mean() for cat in df['categories'].unique()]), key=lambda x: x[1], reverse=True)[:2]]), 'N/A') if 'categories' in df.columns else 'N/A'}
"""

with open(os.path.join(input_folder, 'analysis_report.md'), 'w') as f:
    f.write(report)
print(f"All analysis results have been saved to the '{input_folder}' folder.")